import time


def hello():
    time.sleep(10)
    return "hello world"

